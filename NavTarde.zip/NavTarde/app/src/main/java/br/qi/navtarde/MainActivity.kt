package br.qi.navtarde

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import br.qi.navtarde.ui.theme.NavTardeTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {

        }
    }
}

@Composable
fun MyNav() {
    val navController = rememberNavController()

    NavHost(
        navController = navController,
        startDestination = Rotas.Primeira,
        builder = {
            composable(Rotas.Primeira){
                PrimeiraTela(navController = navController)
            }
            composable(Rotas.Segunda){
                SegundaTela(navController = navController)
            }
            composable(Rotas.Terceira){
                TerceiraTela(navController = navController)
            }
        }
    )
}

///////////////////////////////////////////////////////////
@Preview(
    showBackground = true,
    widthDp = 320,
    heightDp = 640
)
@Composable
fun MyNavPreview() {
    NavTardeTheme {
        MyNav()
    }
}