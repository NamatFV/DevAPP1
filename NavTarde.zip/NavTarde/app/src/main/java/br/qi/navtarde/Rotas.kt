package br.qi.navtarde

object Rotas {
    val Primeira = "tela_1"
    val Segunda = "tela_2"
    val Terceira = "tela_3"
}