package br.qi.navtarde

import android.text.Layout
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController

@Composable
fun PrimeiraTela(
    modifier: Modifier = Modifier,
    navController: NavController
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "PRIMEIRA",
            fontSize = 40.sp,
            fontWeight = FontWeight.ExtraBold
        )

        Button(
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Black
            ),
            onClick = { navController.navigate(Rotas.Segunda) }
        ) {
            Text(
                text = "Ir para a tela 2️⃣",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }//Button

        Button(
            colors = ButtonDefaults.buttonColors(
                containerColor = Color.Black
            ),
            onClick = { navController.navigate(Rotas.Terceira) }
        ) {
            Text(
                text = "Ir para a tela 3️⃣",
                fontSize = 20.sp,
                fontWeight = FontWeight.Bold
            )
        }//Button
    }//Column
}